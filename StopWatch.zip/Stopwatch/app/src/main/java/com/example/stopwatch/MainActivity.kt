package com.example.stopwatch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.Chronometer


class MainActivity : AppCompatActivity() {

    lateinit var btnStart: Button
    lateinit var btnStop: Button
    lateinit var btnReset: Button
    lateinit var chronometer: Chronometer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnReset = findViewById(R.id.btnReset)
        chronometer=findViewById(R.id.chronometer)
        var stopTime: Long = 0

        btnStart.setOnClickListener {
            chronometer.base=SystemClock.elapsedRealtime()+stopTime
            chronometer.start()
        }
        btnStop.setOnClickListener {
            stopTime=chronometer.base-SystemClock.elapsedRealtime()
            chronometer.stop()
        }
        btnReset.setOnClickListener {
            chronometer.base=SystemClock.elapsedRealtime()
            stopTime=0
            chronometer.stop()
        }
    }
}